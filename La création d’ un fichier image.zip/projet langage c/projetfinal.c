#include <stdlib.h>
#include <stdio.h>
#include <complex.h>
#include <math.h>
#include "projetfinal.h"


 pic new_pic(int a,int b){
  pic p;
  p.width=a;
  p.height=b;
  col *c=malloc(a*b*sizeof(col));
   for(int i=0;i<p.height*p.width;i++)
   {
     c[i].red=255;
     c[i].green=255;
     c[i].blue=255;

   }
   p.pix=c;
   return p;
}
void save_pic(pic p,char nom[]){
 FILE*fich = fopen( nom,"w" );
 fputs("P6\n",fich);
 fprintf(fich,"%d %d\n",p.width,p.height);
 fputs("255\n",fich);
 unsigned char str[3];
 for(int i=0;i<p.height*p.width;i++)
 {
    str[0]=p.pix[i].red ;
    str[1]=p.pix[i].green ;
    str[2]=p.pix[i].blue;
    fwrite(str,sizeof(char),3,fich);
 }
 fclose(fich);
 free(p.pix);
}

 void set_pixel(int x,int y,pic p,col c){
  p.pix[abs(y*p.width+x)]=c;


}
 int maximume(int x,int y){
  if(x<y)
    return y;
   return x;
 }

 void draw_line(pic p,int x11,int y11,int x22,int y22,col co){

        int n=maximume(abs(x22-x11),abs(y11-y22));
        int x;
        int y;
        if(n!=0){
        for(int i=0;i<n+1;i++){
                x=x11+i*(x22-x11)/n;
                y=y11+i*(y22-y11)/n;
                set_pixel(x,y,p,co) ;}
           }
   }


 void hexagone(pic p,double x,double y,col co,double oh,double teta){
    draw_line(p,x,y,x+0.335*oh*cos(0.9421+teta),y-0.335*oh*sin(0.9421+teta),co);
    draw_line(p,x+0.335*oh*cos(0.9421+teta),y-0.335*oh*sin(0.9421+teta),x+0.877*oh*cos(-0.0647+teta),y-0.877*oh*sin(-0.0647+teta),co);
    draw_line(p,x+0.877*oh*cos(-0.0647+teta),y-0.877*oh*sin(-0.0647+teta),x+1.086*oh*cos(-0.3+teta),y-1.086*oh*sin(-0.3+teta),co);
    draw_line(p,x+1.086*oh*cos(-0.3+teta),y-1.086*oh*sin(-0.3+teta),x+0.765*oh*cos(-0.263+teta),y-0.765*oh*sin(-0.263+teta),co);
    draw_line(p,x+0.765*oh*cos(-0.263+teta),y-0.765*oh*sin(-0.263+teta),x+0.339*oh*cos(-1.175+teta),y-0.339*oh*sin(-1.175+teta),co);
    draw_line(p,x+0.339*oh*cos(-1.175+teta),y-0.339*oh*sin(-1.175+teta),x,y,co);
}

 void hexag_inv(pic p,double x,double y,col co,double oh,double teta){
    draw_line(p,x,y,x+0.335*oh*cos(0.9421+teta),y+0.335*oh*sin(0.9421+teta),co);
    draw_line(p,x+0.335*oh*cos(0.9421+teta),y+0.335*oh*sin(0.9421+teta),x+0.877*oh*cos(-0.0647+teta),y+0.877*oh*sin(-0.0647+teta),co);
    draw_line(p,x+0.877*oh*cos(-0.0647+teta),y+0.877*oh*sin(-0.0647+teta),x+1.086*oh*cos(-0.3+teta),y+1.086*oh*sin(-0.3+teta),co);
    draw_line(p,x+1.086*oh*cos(-0.3+teta),y+1.086*oh*sin(-0.3+teta),x+0.765*oh*cos(-0.263+teta),y+0.765*oh*sin(-0.263+teta),co);
    draw_line(p,x+0.765*oh*cos(-0.263+teta),y+0.765*oh*sin(-0.263+teta),x+0.339*oh*cos(-1.175+teta),y+0.339*oh*sin(-1.175+teta),co);
    draw_line(p,x+0.339*oh*cos(-1.175+teta),y+0.339*oh*sin(-1.175+teta),x,y,co);

 }

 void quatres_hexagos(pic p, double x,double y,double oh,double teta){
     col rouge={255,0,0};
     col bleu={0,0,255};
     col vert={0,255,0};
     col gris={128,128,128};

     hexagone(p,x+0.12*oh*cos(teta),y-0.12*sin(teta)*oh,rouge,0.27*oh,teta+M_PI/2);
     hexag_inv(p,x+0.08*oh*cos(teta),y-0.08*sin(teta)*oh,bleu,0.3*oh,teta+M_PI/2);
     hexagone(p,x+0.16*cos(teta)*oh,y-0.16*sin(teta)*oh,vert,0.86*oh,teta-0.05);
     hexagone(p,x,y,gris,oh,0);

     }


     void hexa_rec(pic p,double x,double y,col co,double oh,double teta,int m){
            col rouge={255,0,0};
            col bleu={0,0,255};
            col vert={0,0,0};
            col gris={128,128,128};
            col noir={0,0,0};
            if(oh<1){
                  }
         else{if(m%2==0){
            draw_line(p,x,y,x+0.16*oh*cos(teta),y-0.16*oh*sin(teta),noir);
            hexa_rec(p,x+0.16*oh*cos(teta),y-0.16*oh*sin(teta),vert,0.86*oh,teta-0.05,m);
            hexa_rec(p,x+0.12*oh*cos(teta),y-0.12*oh*sin(teta),rouge,0.27*oh,teta+M_PI/2,m);
            hexa_rec(p,x+0.08*oh*cos(teta),y-0.08*oh*sin(teta),bleu,0.3*oh,teta-M_PI/2,m+1);}
            else{
            draw_line(p,x,y,x+0.16*oh*cos(teta),y-0.16*oh*sin(teta),noir);
            hexa_rec(p,x+0.16*oh*cos(teta),y-0.16*oh*sin(teta),vert,0.86*oh,teta+0.05,m);
            hexa_rec(p,x+0.12*oh*cos(teta),y-0.12*oh*sin(teta),rouge,0.27*oh,teta-M_PI/2,m);
            hexa_rec(p,x+0.08*oh*cos(teta),y-0.08*oh*sin(teta),bleu,0.3*oh,teta+M_PI/2,m+1);

            }


            }
       }
