
#include <stdlib.h>
#include <stdio.h>
#include <complex.h>
#include <math.h>
#include "projetfinal.h"

int main(){
     pic pan =new_pic(1600,900);
     col c;
     c.red=0;
     c.blue=0;
     c.green=0;
     double x=M_PI/2;
     //hexagone(pan,300,424,c,100,x);
     //hexag_inv(pan,300,424,c,100,x);
     //quatres_hexagos(pan,300,424,500,0);
     hexa_rec(pan,10,424,c,1500,0,0);
     save_pic(pan,"r.ppm");
     return 0;
   }
