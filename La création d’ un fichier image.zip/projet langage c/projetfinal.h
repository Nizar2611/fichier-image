#include <stdlib.h>
#include <stdio.h>
#include <complex.h>
#include <math.h>
#define M_PI 3.14159265358979323846



typedef struct color{unsigned char red ;
                     unsigned char green;
                      unsigned char blue;}col;
typedef struct picture{int width;
                        int height;
                        col* pix;
                       } pic;

 pic new_pic(int a,int b);
 void save_pic(pic p,char nom[]);
 void set_pixel(int x,int y,pic p,col c);
 int maximume(int x,int y);
 void draw_line(pic p,int x11,int y11,int x22,int y22,col co);
 void hexagone(pic p,double x,double y,col co,double oh,double teta);
 void hexag_inv(pic p,double x,double y,col co,double oh,double teta);
 void quatres_hexagos(pic p, double x,double y,double oh,double teta);
 void hexa_rec(pic p,double x,double y,col co,double oh,double teta,int m);
